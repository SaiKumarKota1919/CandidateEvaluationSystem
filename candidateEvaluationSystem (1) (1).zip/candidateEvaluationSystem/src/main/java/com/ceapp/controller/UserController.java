package com.ceapp.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ceapp.model.User;
import com.ceapp.service.UserService;


@Controller
@RequestMapping("/user")
public class UserController {
	
	
	@Autowired
	UserService userService;
	
	@PostMapping(value="/login")
	public String doLogin(@RequestParam String dasId, @RequestParam 
			String password,Model model,HttpSession httpSession)
	{
		
		
	try {
		User user = userService.doLogin(dasId, password);
		if(user.isLogin()&& user!=null)
		{
			httpSession.setAttribute("curr_user", user);
			return "redirect:/test/candidate/list";
		}
		
	}
	catch (Exception e) {
		e.printStackTrace();
		
		
		
		
		// TODO: handle exception
	}
	model.addAttribute("error", "invalid DASID and password");
		
		return "index";
	}

	@GetMapping("/logout")
	public String doLogout(HttpSession httpSession) {
		
		
		httpSession.invalidate();
		
		return"index";
	}

}
