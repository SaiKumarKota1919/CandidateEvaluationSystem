package com.ceapp.controller;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.dao.DuplicateKeyException;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.ceapp.model.Candidate;
import com.ceapp.model.Feedback;

import com.ceapp.service.CandidateService;
import com.ceapp.service.FeedbackService;
import com.ceapp.service.UserService;

@Controller
@RequestMapping("/candidate")
public class CandidateController {
	
@Autowired
CandidateService candidateService;
@Autowired
FeedbackService feedbackService;
@Autowired
UserService userService;
@Autowired
DataSource dataSource;

public String uploadDirectory="C:\\Users\\a881683\\eclipse-workspace\\candidateEvaluationSystem\\src\\main\\webapp\\WEB-INF\\resources\\resume";


@PostMapping("/save")
public String  save(Candidate candidate,@RequestParam("resume") MultipartFile file,Model m) throws IOException
{
    try 
    {
        System.out.println(candidate);
        String extension = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."));
        String filename = candidate.getcName().replaceAll(" ", "_")+extension;
        Path fileNameAndPath = Paths.get(uploadDirectory,filename);
        Files.write(fileNameAndPath, file.getBytes());
        candidate.setcResume(filename);
        System.out.println(candidate);
       candidateService.add(candidate);
    }
    catch(DuplicateKeyException e) 
    {
    	System.out.println(e.getRootCause());
    	
    	//String duplicateKeyMsg = e.getRootCause().toString();
    	 
    	m.addAttribute("error","Email Id or phone number is already exists try anonther");
//        int startIndex = duplicateKeyMsg.lastIndexOf("' for key '") + 11;
//        int endIndex = duplicateKeyMsg.lastIndexOf("'");
//        
//        String keyName = duplicateKeyMsg.substring(startIndex, endIndex);
//        
//        System.out.println(keyName);
//        
//        if(keyName.equals("candidate.cPhone"))
//        {
//        m.addAttribute("error", "phone number is already exists try anonther");
//        }
//        
//        else{
//			m.addAttribute("error","Email Id is already exists try anonther");
//		}
        
        return "candidateform";
    }
    return "redirect:/test/candidate/list";
}


	@GetMapping(value = "/list")
	public ModelAndView list() {
		ModelAndView mv = new ModelAndView();
        mv.addObject("candidatelist", candidateService.findAll());
        mv.setViewName("candidatelist"); //jsp page name
        return mv;
		
		
	}
	
	@RequestMapping(value="/delete/{cid}")
	public ModelAndView delete(@PathVariable int cid)
	{
		
		candidateService.delete(cid);
		ModelAndView mv = new ModelAndView();
        mv.addObject("candidatelist", candidateService.findAll());
        mv.setViewName("candidatelist"); //jsp page name
        return mv;
		
	}
	
	@RequestMapping("/edit/{candidateId}")
	public String edit(@PathVariable int candidateId,Model model)
	{
		Candidate candidate = candidateService.findById(candidateId);
		model.addAttribute("candidate", candidate);
		return "candidateform";
	}
	
	@GetMapping(value = "/form")
	public ModelAndView form() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("candidateform");
		return mv;
		
		
	}
	
	@PostMapping(value="/update")
	public String  update(Candidate candidate,@RequestParam("resume") MultipartFile file,Model m) throws IOException
	{
	
	    try 
	    {
	    
	        System.out.println(candidate);
	        if(!file.isEmpty())
	        {
	        	
	        String extension = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."));
	        String filename = candidate.getcName().replaceAll(" ", "_")+extension;
	        Path fileNameAndPath = Paths.get(uploadDirectory,filename);
	        Files.write(fileNameAndPath, file.getBytes());
	        candidate.setcResume(filename);
	        }
	        else {
				Candidate candidate2 = candidateService.findById(candidate.getCid());
				candidate.setcResume(candidate2.getcResume());
			}
	        System.out.println(candidate);
	       candidateService.update(candidate);
	    }
	    catch(DuplicateKeyException e) 
	    {
	    	System.out.println(e.getRootCause());
	    	
	    	String duplicateKeyMsg = e.getRootCause().toString();
	    	 

	        int startIndex = duplicateKeyMsg.lastIndexOf("' for key '") + 11;
	        int endIndex = duplicateKeyMsg.lastIndexOf("'");
	        
	        String keyName = duplicateKeyMsg.substring(startIndex, endIndex);
	        
	        System.out.println(keyName);
	        
	        if(keyName.equals("candidate.cPhone"))
	        {
	        m.addAttribute("error", "phone number is already exists try anonther");
	        }
	        
	        else{
				m.addAttribute("error","Email Id is already exists try anonther");
			}
	        
	        return "candidateform";
	    }
	    return "redirect:/test/candidate/list";
	}
	
	
	//candidateController ----------------
	
	@GetMapping("/view/{candidateId}")
	public ModelAndView details(@PathVariable int candidateId)
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("candidatefeedback");
		Candidate candidate = candidateService.findById(candidateId);
		List<Feedback> fList = feedbackService.findByCandidate(candidateId);
		candidate.setCandidateFeedback(fList);
		boolean flag = candidate.getCandidateFeedback().stream().anyMatch(f->f.geteFeedBack().equals("not selected")||f.geteLevel().equals("L3"));
        System.out.println(flag);
        mv.addObject("feedbackStatus",flag);
		mv.addObject(candidate);
		
		return mv;
	}


}
