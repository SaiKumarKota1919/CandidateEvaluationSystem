package com.ceapp.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestParam;

import com.ceapp.model.Candidate;
import com.ceapp.model.Feedback;
import com.ceapp.service.CandidateService;
import com.ceapp.service.FeedbackService;
import com.ceapp.service.UserService;

@Controller
@RequestMapping("/feedback")
public class FeedbackController 
{
	@Autowired 
	CandidateService candidateService;
	
	@Autowired
	UserService userService;
	
	@Autowired
	FeedbackService feedbackService;
	
	
	

//	@RequestMapping("/add/{candidateId}")
//	public String add(Model model,@PathVariable int candidateId)
//	{
//		
//		
////		model.addAttribute("candidatelist", candidateService.findAll());
////		model.addAttribute("interviewerlist", userService.findAll());
////		Candidate candidate = candidateService.findById(candidateId);
////		model.addAttribute("candidate", candidate);
////		List<String> l1 = candidate.getCandidateFeedback().stream().map(m->m.geteLevel()).toList(); 
////		screeninglevels.removeAll(l1);
////		model.addAttribute("screeningLevels",screeninglevels);
////		
////		return "feedbackform";
//	}
	@RequestMapping("/bycandidate/{candidateId}")
	public String feedbackByCandidate(@PathVariable int candidateId,Model model)
	{
		
		model.addAttribute("feedback", feedbackService.findByCandidate(candidateId));
		return "candidatefeedback";
	}
	
	@PostMapping("/save")
	public String save(Feedback feedback,@RequestParam("euid") int euid,@RequestParam("cId") int cid)
	{
		System.out.println(feedback.geteFeedBack());
		feedback.setFeedbackCandidate(candidateService.findById(cid));
		feedback.setFeedbackEvalutorId(userService.findById(euid));
		System.out.println(feedback);
		feedbackService.add(feedback);
		
		return"redirect:/test/candidate/list";
	}

	@RequestMapping("/list")
	public String list(Model model)
	{
		
		model.addAttribute("feedbacklist", feedbackService.findAll());
		return "feedbacklist";
	}
	
	
	 
	@GetMapping("/filter")
	public String filterFeedback(@RequestParam("filter") String filter,Model model)
	{
		System.out.println(filter);
		if(filter.equals("all"))
		{
			model.addAttribute("feedbacklist", feedbackService.findAll());
		}
		else {
			model.addAttribute("feedbacklist",feedbackService.findByFilter(filter));
		}
		
		
		return"feedbacklist";
	}
	
	
	@GetMapping("/form/{candidateId}")
	public String feedbackForm(@PathVariable int candidateId,Model model)
	{
		List<String> screeninglevels = new ArrayList<>(Arrays.asList("L1","L2","L3"));
		
		Candidate candidate = candidateService.findById(candidateId);
		candidate.setCandidateFeedback(feedbackService.findByCandidate(candidateId));
		List<String> l1 = candidate.getCandidateFeedback().stream().map(f->f.geteLevel()).toList();
		System.out.println(l1);
		screeninglevels.removeAll(l1);
		model.addAttribute("screeningLevels",screeninglevels);
		model.addAttribute(candidate);
		
		return "feedbackform";
	}
}

