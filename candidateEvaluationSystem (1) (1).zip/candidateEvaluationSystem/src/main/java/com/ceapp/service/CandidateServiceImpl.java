package com.ceapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ceapp.model.Candidate;
import com.ceapp.repository.CandidateRepo;

@Service
public class CandidateServiceImpl implements CandidateService {
	
	@Autowired
	CandidateRepo candidateRepo;
	
	
	
	

	public CandidateRepo getCandidateRepo() {
		return candidateRepo;
	}

	public void setCandidateRepo(CandidateRepo candidateRepo) {
		this.candidateRepo = candidateRepo;
	}

	@Override
	public void add(Candidate candidate) {
		candidateRepo.add(candidate);
		
	}

	@Override
	public List<Candidate> findAll() {
		// TODO Auto-generated method stub
		return candidateRepo.findAll();
	}

	@Override
	public Candidate findById(int id) {
		// TODO Auto-generated method stub
		
		return candidateRepo.findById(id); 
	}

	@Override
	public void delete(int candidateId) {
		candidateRepo.delete(candidateId);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Candidate candidate) {
		
		candidateRepo.update(candidate);
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Candidate> findSeleted() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Candidate> findNotSeleted() {
		// TODO Auto-generated method stub
		return null;
	}

}
