package com.ceapp.service;

import java.util.List;

import com.ceapp.model.User;

public interface UserService {
	
	User doLogin(String dasId, String password);
	List<User> findAll();
	User findById(int id);

}
