package com.ceapp.service;

import java.util.List;

import com.ceapp.model.Feedback;

public interface FeedbackService {
	void add(Feedback feedback);
	List<Feedback> findAll();
	Feedback findById(int id);
	List<Feedback> findByInterviewer(int id);
	List<Feedback> findByCandidate(int id);
	List<Feedback> findByFilter(String filter);
}
