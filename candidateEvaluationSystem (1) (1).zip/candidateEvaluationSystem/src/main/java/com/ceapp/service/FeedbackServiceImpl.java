package com.ceapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ceapp.model.Feedback;

import com.ceapp.repository.FeedbackRepo;

@Service
public class FeedbackServiceImpl implements FeedbackService{

	@Autowired
	FeedbackRepo feedbackRepo;
	@Override
	public List<Feedback> findByCandidate(int candidateId) {
		// TODO Auto-generated method stub
		
		return feedbackRepo.findByCandidate(candidateId);
	}

	@Override
	public void add(Feedback feedback) {
		
	feedbackRepo.add(feedback);
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Feedback> findAll() {
		// TODO Auto-generated method stub
		return feedbackRepo.findAll();
	}

	@Override
	public Feedback findById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Feedback> findByInterviewer(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Feedback> findByFilter(String filter) {
		// TODO Auto-generated method stub
		return feedbackRepo.findByFilter(filter);
	}

}
