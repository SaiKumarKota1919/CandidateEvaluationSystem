package com.ceapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ceapp.model.User;
import com.ceapp.repository.UserRepo;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserRepo userRepo;

	@Override
	public User doLogin(String dasId, String password) {
		// TODO Auto-generated method stub
		
		
		User user = this.userRepo.doLogin(dasId, password);
		if(user!=null)
		{
			user.setLogin(true);
		}
		return user;
		
	}

	@Override
	public List<User> findAll() {
	
		// TODO Auto-generated method stub
		return userRepo.findAll();
	}

	@Override
	public User findById(int id) {
		// TODO Auto-generated method stub
		return userRepo.findByID(id);
	}

}
