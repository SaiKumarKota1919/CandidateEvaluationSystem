package com.ceapp.repository;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;


import com.ceapp.model.User;

@Repository
public class UserRepoImpl implements UserRepo{
	
	String sqlQuery;
	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public User doLogin(String dasId, String password) {
		// TODO Auto-generated method stub
		sqlQuery ="select * from euser where uDasId=? and uPassword=?";
		RowMapper<User> rowMapperForUser =(rs,rowcnt)->{
			User u = new User();
			u.setEuid(rs.getInt("euid"));
			u.setUname(rs.getString(4));
			
			
			return u;
		};
		
		
		
		User user =this.jdbcTemplate.queryForObject(sqlQuery, rowMapperForUser,dasId,password);
		
		//System.out.println( user);
		return user;
		
	}

	@Override
	public List<User> findAll() {
		sqlQuery="select * from euser";
		RowMapper<User> rowMapperforCandidate = (rs,rowcnt)->{
            User user = new User();
           user.setEuid(rs.getInt(1));
           user.setuDasId(rs.getString(2));
           user.setuPassword(rs.getString(3));
           user.setUname(rs.getString(4));
           user.setuEmail(rs.getString(5));
           user.setuGcm(rs.getInt(6));
           user.setuManagerId(rs.getInt(7));
           user.setuRole(rs.getString(8));
           
            return user;
        };
        List<User> ulist = this.jdbcTemplate.query(sqlQuery, rowMapperforCandidate);
        
       // System.out.println("candidate list "+clist);
        return ulist;
		
	}

	@Override
	public User findByID(int id) {
		sqlQuery="select * from euser where euid=?";
		RowMapper<User> userRowMapper = (rs,rowcnt)->new User(rs.getInt(1)
				,rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),
				rs.getInt(6),rs.getInt(7),rs.getString(8));
		
		return this.jdbcTemplate.queryForObject(sqlQuery,userRowMapper,id);
	}

	

}
