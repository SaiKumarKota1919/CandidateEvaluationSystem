package com.ceapp.repository;

import java.util.List;

import com.ceapp.model.Candidate;

public interface CandidateRepo {
	void add(Candidate candidate);
    List<Candidate> findAll();
    Candidate findById(int id);

    void delete(int candidateId);
    void update(Candidate candidate);
    List<Candidate> findSeleted();
    List<Candidate> findNotSeleted();

}
