package com.ceapp.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.ceapp.model.Feedback;


@Repository
public class FeedbackRepoImpl implements FeedbackRepo {
   String sqlQuery;
   @Autowired
   JdbcTemplate jdbcTemplate;
  @Autowired
  CandidateRepo candidateRepo;
   
   //feedbackRepo--------------------------
   
   
	@Override
	public List<Feedback> findByCandidate(int candidateId) {
		 sqlQuery="select * from evaluation where cid=?";
		 RowMapper<Feedback> rowMapper =(rs,cnt)->{
			 Feedback feedback = new Feedback();
			 feedback.seteId(rs.getInt(1));
			 feedback.seteLevel(rs.getString(5));
			 feedback.setEvaluatorName(rs.getString(8));
			 feedback.seteComments(rs.getString(7));
			 feedback.seteFeedBack(rs.getString(6));
			 return feedback;
		 };
		return this.jdbcTemplate.query(sqlQuery,rowMapper,candidateId);
	}

	@Override
	public void add(Feedback feedback) {
		sqlQuery="insert into evaluation(cId,euid,eDate,eLevel,eFeedBack,eComments,evaluatorName) values(?,?,?,?,?,?,?)";
		this.jdbcTemplate.update(sqlQuery,feedback.getcId(),feedback.getEuid(),
				feedback.geteDate(),feedback.geteLevel(),feedback.geteFeedBack(),
				feedback.geteComments(),feedback.getEvaluatorName());
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Feedback> findAll() {
		sqlQuery="select * from evaluation where cId in(select cid from  candidate where isactive=1)";
		RowMapper<Feedback> rowMapper =(rs,rowcnt)->{
			Feedback feedback =new Feedback();
			feedback.seteId(rs.getInt(1));
			feedback.setcId(rs.getInt(2));
			feedback.setEuid(rs.getInt(3));
			feedback.seteDate(rs.getString(4));
			feedback.seteLevel(rs.getString(5));
			feedback.seteFeedBack(rs.getString(6));
			feedback.seteComments(rs.getString(7));
			feedback.setEvaluatorName(rs.getString(8));
			feedback.setFeedbackCandidate(candidateRepo.findById(rs.getInt(2)));
			
			return feedback;
			
		};
		List<Feedback> fList = this.jdbcTemplate.query(sqlQuery, rowMapper);
	return fList;
	}

	@Override
	public Feedback findById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Feedback> findByInterviewer(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Feedback> findByFilter(String filter) {
		// TODO Auto-generated method stub
		sqlQuery="select * from evaluation where cId in(select cid from  candidate where isactive=1) AND eFeedBack=?";
		RowMapper<Feedback> rowMapper =(rs,rowcnt)->{
			Feedback feedback =new Feedback();
			feedback.seteId(rs.getInt(1));
			feedback.setcId(rs.getInt(2));
			feedback.setEuid(rs.getInt(3));
			feedback.seteDate(rs.getString(4));
			feedback.seteLevel(rs.getString(5));
			feedback.seteFeedBack(rs.getString(6));
			feedback.seteComments(rs.getString(7));
			feedback.setEvaluatorName(rs.getString(8));
			feedback.setFeedbackCandidate(candidateRepo.findById(rs.getInt(2)));
			
			return feedback;
			
		};
		List<Feedback> fList = this.jdbcTemplate.query(sqlQuery, rowMapper,filter);
	return fList;
	}

}
