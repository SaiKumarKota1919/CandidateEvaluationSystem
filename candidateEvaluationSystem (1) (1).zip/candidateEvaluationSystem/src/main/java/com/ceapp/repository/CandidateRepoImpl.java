package com.ceapp.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.ceapp.model.Candidate;

@Repository
public class CandidateRepoImpl implements CandidateRepo {
	
	
	@Autowired
	JdbcTemplate jdbcTemplate;

	String sqlQuery;
	@Override
	public void add(Candidate candidate) {
	sqlQuery="insert into candidate(cName,cPhone,cEmail,cComment,cResume,cEnrollmentDate) values(?,?,?,?,?,?)";
	this.jdbcTemplate.update(sqlQuery,
			candidate.getcName(),
			candidate.getcPhone(),
			candidate.getcEmail(),
			candidate.getcComment(),
			candidate.getcResume(),
			candidate.getcEnrollmentDate());
	
		
	}

	
	
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}




	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}




	@Override
	public List<Candidate> findAll() {
		// TODO Auto-generated method stub
		
		sqlQuery="select * from candidate where isactive=1";
		RowMapper<Candidate> rowMapperforCandidate = (rs,rowcnt)->{
            Candidate  c = new Candidate();
            c.setCid(rs.getInt(1));
            c.setcName(rs.getString(2));
            c.setcEmail(rs.getString(3));
            c.setcPhone(rs.getLong(4));
            c.setcResume(rs.getString(5));
            c.setcComment(rs.getString(6));
            c.setcEnrollmentDate(rs.getString(7));
            
            return c;
        };
        List<Candidate> clist = this.jdbcTemplate.query(sqlQuery, rowMapperforCandidate);
        
       // System.out.println("candidate list "+clist);
        return clist;
		
	}

	@Override
	public Candidate findById(int id) {
		// TODO Auto-generated method stub
		sqlQuery="select * from candidate where cid=?";
		RowMapper<Candidate> candidateRowMapper = (rs,rowcnt)->new Candidate(rs.getInt(1), 
				rs.getString(2), rs.getString(3),
				rs.getLong(4), rs.getString(5),
				rs.getString(6),rs.getString(7));
		
		return this.jdbcTemplate.queryForObject(sqlQuery,candidateRowMapper,id);
	}

	@Override
	public void delete(int candidateId) {
		
		sqlQuery="update  candidate set isactive=0 where cid=?";
		this.jdbcTemplate.update(sqlQuery,candidateId);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Candidate candidate) {
		sqlQuery="update candidate set cName=?,cPhone=?,cEmail=?,cComment=?,cResume=?,cEnrollmentDate=? where cId="+candidate.getCid();
		this.jdbcTemplate.update(sqlQuery,
				candidate.getcName(),
				candidate.getcPhone(),
				candidate.getcEmail(),
				candidate.getcComment(),
				candidate.getcResume(),
				candidate.getcEnrollmentDate());
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Candidate> findSeleted() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Candidate> findNotSeleted() {
		// TODO Auto-generated method stub
		return null;
	}
	

}
