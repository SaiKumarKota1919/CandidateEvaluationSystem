package com.ceapp.repository;

import java.util.List;

import com.ceapp.model.User;

public interface UserRepo {
	List<User> findAll();
	User findByID(int id);
	 User doLogin(String dasId,String password);

}
