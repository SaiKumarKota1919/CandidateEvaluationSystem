package com.ceapp.model;

public class Feedback {
	
	private int eId;
	private int cId;
	private int euid;
	private String eDate;
	private String eLevel;
	private String eFeedBack;
	private String eComments;
	private User feedbackEvalutorId;
	private Candidate  feedbackCandidate;
	private String evaluatorName;
	public Feedback(int eId, int cId, int euid, String eDate, String eLevel, String eFeedBack, String eComments,
			User feedbackEvalutorId, Candidate feedbackCandidate, String evaluatorName) {
		super();
		this.eId = eId;
		this.cId = cId;
		this.euid = euid;
		this.eDate = eDate;
		this.eLevel = eLevel;
		this.eFeedBack = eFeedBack;
		this.eComments = eComments;
		this.feedbackEvalutorId = feedbackEvalutorId;
		this.feedbackCandidate = feedbackCandidate;
		this.evaluatorName = evaluatorName;
	}
	public Feedback() {
		super();
	}
	public int geteId() {
		return eId;
	}
	public void seteId(int eId) {
		this.eId = eId;
	}
	public int getcId() {
		return cId;
	}
	public void setcId(int cId) {
		this.cId = cId;
	}
	public int getEuid() {
		return euid;
	}
	public void setEuid(int euid) {
		this.euid = euid;
	}
	public String geteDate() {
		return eDate;
	}
	public void seteDate(String eDate) {
		this.eDate = eDate;
	}
	public String geteLevel() {
		return eLevel;
	}
	public void seteLevel(String eLevel) {
		this.eLevel = eLevel;
	}
	public String geteFeedBack() {
		return eFeedBack;
	}
	public void seteFeedBack(String eFeedBack) {
		this.eFeedBack = eFeedBack;
	}
	public String geteComments() {
		return eComments;
	}
	public void seteComments(String eComments) {
		this.eComments = eComments;
	}
	public User getFeedbackEvalutorId() {
		return feedbackEvalutorId;
	}
	public void setFeedbackEvalutorId(User feedbackEvalutorId) {
		this.feedbackEvalutorId = feedbackEvalutorId;
	}
	public Candidate getFeedbackCandidate() {
		return feedbackCandidate;
	}
	public void setFeedbackCandidate(Candidate feedbackCandidate) {
		this.feedbackCandidate = feedbackCandidate;
	}
	public String getEvaluatorName() {
		return evaluatorName;
	}
	public void setEvaluatorName(String evaluatorName) {
		this.evaluatorName = evaluatorName;
	}
	@Override
	public String toString() {
		return "Feedback [eId=" + eId + ", cId=" + cId + ", euid=" + euid + ", eDate=" + eDate + ", eLevel=" + eLevel
				+ ", eFeedBack=" + eFeedBack + ", eComments=" + eComments + ", feedbackEvalutorId=" + feedbackEvalutorId
				+ ", feedbackCandidate=" + feedbackCandidate + ", evaluatorName=" + evaluatorName + "]";
	}
	
	
	

	
	

}
