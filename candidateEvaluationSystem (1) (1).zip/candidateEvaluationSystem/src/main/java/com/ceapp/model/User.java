package com.ceapp.model;

public class User {
	private int euid;
	private String uDasId;
	private String uPassword;
	private String uname;
	private String uEmail;
	private int uGcm;
	private int uManagerId;
	private String uRole;
	private boolean isLogin;
	
	
	
	public User(int euid, String uDasId, String uPassword, String uname, String uEmail, int uGcm, int uManagerId,
			String uRole) {
		super();
		this.euid = euid;
		this.uDasId = uDasId;
		this.uPassword = uPassword;
		this.uname = uname;
		this.uEmail = uEmail;
		this.uGcm = uGcm;
		this.uManagerId = uManagerId;
		this.uRole = uRole;
	}
	
	
	public User() {
		super();
	}


	
	public boolean isLogin() {
		return isLogin;
	}


	public void setLogin(boolean isLogin) {
		this.isLogin = isLogin;
	}


	public int getEuid() {
		return euid;
	}


	public void setEuid(int euid) {
		this.euid = euid;
	}


	public String getuDasId() {
		return uDasId;
	}


	public void setuDasId(String uDasId) {
		this.uDasId = uDasId;
	}


	public String getuPassword() {
		return uPassword;
	}


	public void setuPassword(String uPassword) {
		this.uPassword = uPassword;
	}


	public String getUname() {
		return uname;
	}


	public void setUname(String uname) {
		this.uname = uname;
	}


	public String getuEmail() {
		return uEmail;
	}


	public void setuEmail(String uEmail) {
		this.uEmail = uEmail;
	}


	public int getuGcm() {
		return uGcm;
	}


	public void setuGcm(int uGcm) {
		this.uGcm = uGcm;
	}


	public int getuManagerId() {
		return uManagerId;
	}


	public void setuManagerId(int uManagerId) {
		this.uManagerId = uManagerId;
	}


	public String getuRole() {
		return uRole;
	}


	public void setuRole(String uRole) {
		this.uRole = uRole;
	}


	@Override
	public String toString() {
		return "User [euid=" + euid + ", uDasId=" + uDasId + ", uPassword=" + uPassword + ", uname=" + uname
				+ ", uEmail=" + uEmail + ", uGcm=" + uGcm + ", uManagerId=" + uManagerId + ", uRole=" + uRole + "]";
	}
	
	
	
	

}
