package com.ceapp.model;

import java.util.List;

public class Candidate {
	private int cid;
	private String cName;
	private String cEmail;
	private Long cPhone;
	private String cResume;
	private String cComment;
	private String cEnrollmentDate;
	private List<Feedback> candidateFeedback;
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getcEmail() {
		return cEmail;
	}
	public void setcEmail(String cEmail) {
		this.cEmail = cEmail;
	}
	public Long getcPhone() {
		return cPhone;
	}
	public void setcPhone(Long cPhone) {
		this.cPhone = cPhone;
	}
	public String getcResume() {
		return cResume;
	}
	public void setcResume(String cResume) {
		this.cResume = cResume;
	}
	public String getcComment() {
		return cComment;
	}
	public void setcComment(String cComment) {
		this.cComment = cComment;
	}
	public String getcEnrollmentDate() {
		return cEnrollmentDate;
	}
	public void setcEnrollmentDate(String cEnrollmentDate) {
		this.cEnrollmentDate = cEnrollmentDate;
	}
	public List<Feedback> getCandidateFeedback() {
		return candidateFeedback;
	}
	public void setCandidateFeedback(List<Feedback> candidateFeedback) {
		this.candidateFeedback = candidateFeedback;
	}
	
	
	public Candidate(int cid, String cName, String cEmail, Long cPhone, String cResume, String cComment,
			String cEnrollmentDate) {
		super();
		this.cid = cid;
		this.cName = cName;
		this.cEmail = cEmail;
		this.cPhone = cPhone;
		this.cResume = cResume;
		this.cComment = cComment;
		this.cEnrollmentDate = cEnrollmentDate;
	}
	public Candidate(int cid, String cName, String cEmail, Long cPhone, String cResume, String cComment,
			String cEnrollmentDate, List<Feedback> candidateFeedback) {
		super();
		this.cid = cid;
		this.cName = cName;
		this.cEmail = cEmail;
		this.cPhone = cPhone;
		this.cResume = cResume;
		this.cComment = cComment;
		this.cEnrollmentDate = cEnrollmentDate;
		this.candidateFeedback = candidateFeedback;
	}
	public Candidate() {
		super();
	}
	@Override
	public String toString() {
		return "Candidate [cid=" + cid + ", cName=" + cName + ", cEmail=" + cEmail + ", cPhone=" + cPhone + ", cResume="
				+ cResume + ", cComment=" + cComment + ", cEnrollmentDate=" + cEnrollmentDate + ", candidateFeedback="
				+ candidateFeedback + "]";
	}
	
	
	
	
	

}
